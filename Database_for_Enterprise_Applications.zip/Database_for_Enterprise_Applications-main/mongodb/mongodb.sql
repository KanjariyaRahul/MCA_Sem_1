1.
2. what is difference nosql and rdbms
3. explain collection in mongodb and how do we insert data in it.
4.how can we use select function in mongodb.
5.explain $exit in mongodb with example.
6. syntax and example $in, $and, $or in mongodb.
7. $it
8.explain $set in mongodb with syntax and example /or
9. explain update function white sex white example. / or
10 explain update and updatemany syntax and example. /or
11. explain upsert in mongodb with syntax and example
12. explain $inc and $puts with syntax and example.
13. explain insertOne And insertMany with syntax and example
14. explain sort() in mongodb and with syntax and example .
15. explain limit in mongodb and with syntax and example .
16. explain skip() in mongodb and with syntax and example .
17 explain count() in mongodb and whit syntax and example .
18. explain to update in mongodb white syntax and example
19. explain when to use mongodb.
20. explain flexible schema in mongodb.