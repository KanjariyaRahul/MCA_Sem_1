SELECT * FROM DUAL;

SELECT 2*16 from DUAL;

SELECT (2+4)/2*16 from DUAL;

SELECT (2*5-3)/2+16 from DUAL;

SELECT to_date('17-aug-2023') from dual;

SELECT to_date('17-aug-2023')+2 from dual;
SELECT to_date('17-aug-2023')-3 from dual;

SELECT to_date('17-aug-2023')+395 from dual;

SELECT to_date('17-aug-2023')- to_date('15-aug-2023') from dual;
SELECT ((to_date('17-aug-2023')- to_date('22-feb-2003'))/30)/12 from dual;

SELECT ((to_date('17-aug-2023')- to_date('22-feb-2003'))/30)/12 from dual;
