//Implicit Type Conversion char to int

#include<stdio.h>

int main() {

  char alphabet = 'a';

  int number = alphabet;
  printf("Integer Value 'a' is : %d", number);

  return 0;
}
