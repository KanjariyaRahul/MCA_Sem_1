#include<stdio.h>
#include <stdbool.h>

 main()
 {
  int a = 4, b=5;
   printf("output And = %d\n",a&b);
   printf("output Or = %d\n",a|b);
   printf("output Not = %d\n",~a);
   printf("output Xor = %d\n",a^b);
   printf("output ShiftRight = %d\n",a>>b);
   printf("output ShiftLeft = %d\n",a<<b);

 }

