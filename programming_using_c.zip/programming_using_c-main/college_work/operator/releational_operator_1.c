//releational operator like " == ,!=, < , > ,<= , >= "

#include<stdio.h>

main()
{

    int a=5 , b=10 ;

    printf("%d == %d is %d \n", a, b, a == b);
    printf("%d != %d is %d \n", a, b, a != b);
    printf("%d > %d is %d \n", a, b, a > b);
    printf("%d >= %d is %d \n", a, b, a >= b);
    printf("%d < %d is %d \n", a, b, a < b);
    printf("%d <= %d is %d \n", a, b, a <= b);
}

