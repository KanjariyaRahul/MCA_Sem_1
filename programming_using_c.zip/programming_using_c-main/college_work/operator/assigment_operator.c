//assigment operator in " =, +=, -=,*=,/=,%= "

#include<stdio.h>

main(){

   int a = 10;
   int c ;

    c=a;
    printf("Value of c = %d\n", c );

    c+=a;
    printf("Value of c += %d\n", c );

     c-=a;
    printf("Value of c -= %d\n", c );

     c*=a;
    printf("Value of c *= %d\n", c );

     c/=a;
    printf("Value of c /= %d\n", c );

     c%=a;
    printf("Value of c %= %d\n", c );


}

