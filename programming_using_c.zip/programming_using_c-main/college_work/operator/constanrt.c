#include<stdio.h>
main(){

    const int int_const = 25;
    const float float_const =15.66;
    const char char_const = 'A';
    //const string string_const ="rahul";
   printf("Printing value of Integer Constant: %d\n\n",
           int_const);
    printf("Printing value of Character Constant: %c\n\n",
           char_const);
    printf("Printing value of Float Constant: %f",
           float_const);

}
