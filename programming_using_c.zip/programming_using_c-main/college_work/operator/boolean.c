#include<stdio.h>
#include <stdbool.h>

 main()
 {
     bool a = true;
     printf(" a== %d",a);

     int x=10, y=10;

    printf("\n a == b  = %d",x==y);
    printf("\n a != b  = %d",x!=y);
    printf("\n a <  b  = %d",x<y);
    printf("\n a <= b  = %d",x<=y);
    printf("\n a >  b  = %d",x>y);
    printf("\n a >= b  = %d",x>=y);

 }

