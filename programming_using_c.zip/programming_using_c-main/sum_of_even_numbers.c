//write a program calculate sum of even numbers from 1 to n using for loop.

#include <stdio.h>
#include <stdlib.h>

int main()
{
    int i,n,sum=0;

    printf("Enter any number :");
    scanf("%d",&n);

    for(i=2;i<=n;i+=2)
    {

         sum += i;
    }

      printf("Sum of all even number between 1 to %d = %d", n, sum);

    return 0;
}
