var term1 = 0, term2 = 1;
var nextterm = 0;
var num = 10;
console.log("Fibonacci Series  \n " + term1 + "\n" + term2);
